def cylinder():
    a=int(input("1-площадь боковой поверхности 2- полная площадь целиндра "))
    h=int(input("введите высоту цилиндра"))
    r=int(input("введите радиус круга "))
    p=3.14
    def circle():
        Scircle=p*r**2
        if a==1:
            bok=2*p*r*h
            print(bok)
        elif a==2:
            poln=(Scircle*2)+bok
            print(poln)
cylinder()
